# Provisioning d'infrastructure via Red Hat Satellite (Ansible)

Ce projet construit toute la chaîne de provisioning d'un Satellite 6.x avec la collection `redhat.satellite` : organisation, contenu, content views, réseau, templates, compute resource, host groups, création des VM, puis post-config via Remote Execution.

Tout ce qui décrit l'infra est dans **`vars/infra.yml`**. Les playbooks n'ont pas besoin d'être modifiés.

## Arborescence

```
ansible.cfg
requirements.yml
site.yml                         # enchaîne tout (avec tags)
inventory/
  hosts.ini                      # localhost (on parle à l'API)
  group_vars/all/satellite.yml   # URL + identifiants API
  group_vars/all/vault.yml.example
vars/infra.yml                   # description déclarative de l'infra
playbooks/
  01_organisation.yml            # org, locations, capsule, LCE path
  02_contenu.yml                 # manifest, repos RH, synchro async, sync plan
  03_content_views.yml           # CV, publish, promote Dev->QA->Prod, activation keys
  04_reseau.yml                  # domaine, subnet (TFTP/templates/REX via capsule)
  05_os_templates.yml            # OS RedHat 9.x + templates Kickstart par défaut
  06_compute.yml                 # compute resource libvirt (VMware en commentaire) + profiles
  07_hostgroups.yml              # hg-rhel9 parent + enfants dev/prod
  08_provision_hosts.yml         # création des hôtes + attente fin d'install
  09_post_provisioning.yml       # job template Ansible (bannière) + job invocation
templates/banner_job_template.erb
files/manifest.zip               # à déposer (non fourni)
```

## Prérequis

1. Installer la collection :
   `ansible-galaxy collection install -r requirements.yml`
   (`redhat.satellite` vient d'Automation Hub. Sans token, utiliser `theforeman.foreman` et remplacer le préfixe `redhat.satellite.` par `theforeman.foreman.`, ainsi que `group/redhat.satellite.satellite` par `group/theforeman.foreman.foreman`.)
2. `pip install apypie` (ou `dnf install python3-apypie`) sur la machine de contrôle.
3. Déposer le manifest dans `files/manifest.zip`.
4. Créer le vault :
   ```bash
   cp inventory/group_vars/all/vault.yml.example inventory/group_vars/all/vault.yml
   ansible-vault encrypt inventory/group_vars/all/vault.yml
   echo 'motdepasse' > ~/.vault_pass && chmod 600 ~/.vault_pass
   ```
5. Pour libvirt : déployer la clé SSH de l'utilisateur `foreman` sur l'hyperviseur.
   ```bash
   sudo -u foreman ssh-keygen -f /usr/share/foreman/.ssh/id_rsa -N ''
   sudo -u foreman ssh-copy-id root@kvm01.lab.local
   ```

## Utilisation

```bash
ansible-playbook site.yml                          # tout
ansible-playbook site.yml --tags org,contenu       # fondations seulement
ansible-playbook site.yml --tags provision,post    # nouvelles VM
ansible-playbook playbooks/03_content_views.yml --tags promote -e cv_publish=false
ansible-playbook playbooks/09_post_provisioning.yml --tags openscap   # scan OpenSCAP
```

Pour ajouter une VM, ajoute une entrée dans `sat_hosts` puis lance `--tags provision,post`.

## Points à vérifier sur ton Satellite

- **Noms des dépôts** (`sat_repos[].repo`) : ils dépendent de la version. Vérifie-les avec
  `hammer repository list --organization Lab`.
- **Nom de l'OS** : `RedHat 9.4` est créé automatiquement après la synchro du Kickstart
  (`hammer os list`).
- **pxe_loader** : `Grub2 UEFI` pour des VM UEFI, `PXELinux BIOS` pour du BIOS.
- **Promotion** : le playbook 03 promeut jusqu'en Prod d'un coup. En production réelle, retire Prod de la boucle
  ou utilise `--tags promote` après validation en QA.
- **IPAM** : `Internal DB` avec boot statique par défaut. Passe à `DHCP` avec `dhcp_proxy` si la Capsule gère le DHCP.
